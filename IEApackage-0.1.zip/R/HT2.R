library(Rcpp)

setwd('G:\\V6\\V7\\IEApackage-0.1\\R\\')

Rcpp::sourceCpp('hygecdf2.cpp')    
hygecdf2(5,3,1000,100,50,30)  
hygecdf2(6,15,1000,200,10,100)        
hygecdf2(2,10,500,20,10,100)   
        