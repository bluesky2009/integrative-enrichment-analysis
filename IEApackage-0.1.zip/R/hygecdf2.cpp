﻿#include <Rcpp.h>//必须的头文件  
#include <string>
using namespace Rcpp;  
using namespace std;

// [[Rcpp::export]]  
double hygecdf2(int k1, int k2, int N, int b, int a1, int a2) 
{        
    double P = 1;
    string debug;
    
    for(int i1=0; i1<=k1; i1++)
    {
        for(int i2=0; i2<=k2; i2++)
        {
            double s = 1;
            
            int ui=1;
            int di=1;
            int d1=1;
            int d2=1;
            int d3=1;
            int d4=1;
            int d5=1;
            int d6=1;
            int d7=1;
            int u1=1;
            int u2=1;
            int u3=1;
            int u4=1;
            int u5=1;
            
            if(a1<0 || a2<0 || N-a1-a2<0 || b<0 || N-b<0 || i1<0 || i2<0 || a1-i1<0 || a2-i2<0 || b-i1-i2<0 || N-b-a1-a2+i1+i2<0)
                s = 0;
            else
            {
                while(ui<=5 or di<=7)
                {
                    if ((s>=1 and di<=7) or ui>5)
                    {
                        if(di==1)
                        {
                            debug = 'd1';
                            s = s*1.0/d1;
                            d1 = d1 + 1;
                            if(d1>N) di = 2;
                        }
                        if(di==2)
                        {
                            debug = 'd2';
                            s = s*1.0/d2;
                            d2 = d2 + 1;
                            if(d2>i1) di = 3;
                        }
                        if(di==3)
                        {
                            debug = 'd3';
                            s = s*1.0/d3;
                            d3 = d3 + 1;
                            if(d3>i2) di = 4;
                        }
                        if(di==4)
                        {
                            debug = 'd4';
                            s = s*1.0/d4;
                            d4 = d4 + 1;
                            if(d4>(a1-i1)) di = 5;
                        }
                        if(di==5)
                        {
                            debug = 'd5';
                            s = s*1.0/d5;
                            d5 = d5 + 1;
                            if(d5>(a2-i2)) di = 6;
                        }
                        if(di==6)
                        {
                            debug = 'd6';
                            s = s*1.0/d6;
                            d6 = d6 + 1;
                            if(d6>(b-i1-i2)) di = 7;
                        }
                        if(di==7)
                        {
                            debug = 'd7';
                            s = s*1.0/d7;
                            d7 = d7 + 1;
                            if(d7>(N-b-a1-a2+i1+i2)) di = 8;
                        }
                    }
                    else if ((s<1 and ui<=5) or di>7)
                    {
                        if(ui==1)
                        {
                            debug = 'u1';
                            s = s*1.0*u1;
                            u1 = u1 + 1;
                            if(u1>b) ui = 2;
                        }
                        if(ui==2)
                        {
                            debug = 'u2';
                            s = s*1.0*u2;
                            u2 = u2 + 1;
                            if(u2>N-b) ui = 3;
                        }
                        if(ui==3)
                        {
                            debug = 'u3';
                            s = s*1.0*u3;
                            u3 = u3 + 1;
                            if(u3>a1) ui = 4;
                        }
                        if(ui==4)
                        {
                            debug = 'u4';
                            s = s*1.0*u4;
                            u4 = u4 + 1;
                            if(u4>a2) ui = 5;
                        }
                        if(ui==5)
                        {
                            debug = 'u5';
                            s = s*1.0*u5;
                            u5 = u5 + 1;
                            if(u5>(N-a1-a2)) ui = 6;
                        }
                    }
                }
                
                if(s<0)
                    s = 0;
                else if(s>1)
                    s = 1;
            }
            P = P-s;
        }
    }


    for(int i1=k1+1; i1<=a1; i1++)
    {
        for(int i2=0; i2<=k2; i2++)
        {
            double s = 1;
            
            int ui=1;
            int di=1;
            int d1=1;
            int d2=1;
            int d3=1;
            int d4=1;
            int d5=1;
            int d6=1;
            int d7=1;
            int u1=1;
            int u2=1;
            int u3=1;
            int u4=1;
            int u5=1;
            
            if(a1<0 || a2<0 || N-a1-a2<0 || b<0 || N-b<0 || i1<0 || i2<0 || a1-i1<0 || a2-i2<0 || b-i1-i2<0 || N-b-a1-a2+i1+i2<0)
                s = 0;
            else
            {
                while(ui<=5 or di<=7)
                {
                    if ((s>=1 and di<=7) or ui>5)
                    {
                        if(di==1)
                        {
                            debug = 'd1';
                            s = s*1.0/d1;
                            d1 = d1 + 1;
                            if(d1>N) di = 2;
                        }
                        if(di==2)
                        {
                            debug = 'd2';
                            s = s*1.0/d2;
                            d2 = d2 + 1;
                            if(d2>i1) di = 3;
                        }
                        if(di==3)
                        {
                            debug = 'd3';
                            s = s*1.0/d3;
                            d3 = d3 + 1;
                            if(d3>i2) di = 4;
                        }
                        if(di==4)
                        {
                            debug = 'd4';
                            s = s*1.0/d4;
                            d4 = d4 + 1;
                            if(d4>(a1-i1)) di = 5;
                        }
                        if(di==5)
                        {
                            debug = 'd5';
                            s = s*1.0/d5;
                            d5 = d5 + 1;
                            if(d5>(a2-i2)) di = 6;
                        }
                        if(di==6)
                        {
                            debug = 'd6';
                            s = s*1.0/d6;
                            d6 = d6 + 1;
                            if(d6>(b-i1-i2)) di = 7;
                        }
                        if(di==7)
                        {
                            debug = 'd7';
                            s = s*1.0/d7;
                            d7 = d7 + 1;
                            if(d7>(N-b-a1-a2+i1+i2)) di = 8;
                        }
                    }
                    else if ((s<1 and ui<=5) or di>7)
                    {
                        if(ui==1)
                        {
                            debug = 'u1';
                            s = s*1.0*u1;
                            u1 = u1 + 1;
                            if(u1>b) ui = 2;
                        }
                        if(ui==2)
                        {
                            debug = 'u2';
                            s = s*1.0*u2;
                            u2 = u2 + 1;
                            if(u2>N-b) ui = 3;
                        }
                        if(ui==3)
                        {
                            debug = 'u3';
                            s = s*1.0*u3;
                            u3 = u3 + 1;
                            if(u3>a1) ui = 4;
                        }
                        if(ui==4)
                        {
                            debug = 'u4';
                            s = s*1.0*u4;
                            u4 = u4 + 1;
                            if(u4>a2) ui = 5;
                        }
                        if(ui==5)
                        {
                            debug = 'u5';
                            s = s*1.0*u5;
                            u5 = u5 + 1;
                            if(u5>(N-a1-a2)) ui = 6;
                        }
                    }
                }
                
                if(s<0)
                    s = 0;
                else if(s>1)
                    s = 1;
            }
            P = P-s;
        }
    }
    
    
    for(int i1=0; i1<=k1; i1++)
    {
        for(int i2=k2+1; i2<=a2; i2++)
        {
            double s = 1;
            
            int ui=1;
            int di=1;
            int d1=1;
            int d2=1;
            int d3=1;
            int d4=1;
            int d5=1;
            int d6=1;
            int d7=1;
            int u1=1;
            int u2=1;
            int u3=1;
            int u4=1;
            int u5=1;
            
            if(a1<0 || a2<0 || N-a1-a2<0 || b<0 || N-b<0 || i1<0 || i2<0 || a1-i1<0 || a2-i2<0 || b-i1-i2<0 || N-b-a1-a2+i1+i2<0)
                s = 0;
            else
            {
                while(ui<=5 or di<=7)
                {
                    if ((s>=1 and di<=7) or ui>5)
                    {
                        if(di==1)
                        {
                            debug = 'd1';
                            s = s*1.0/d1;
                            d1 = d1 + 1;
                            if(d1>N) di = 2;
                        }
                        if(di==2)
                        {
                            debug = 'd2';
                            s = s*1.0/d2;
                            d2 = d2 + 1;
                            if(d2>i1) di = 3;
                        }
                        if(di==3)
                        {
                            debug = 'd3';
                            s = s*1.0/d3;
                            d3 = d3 + 1;
                            if(d3>i2) di = 4;
                        }
                        if(di==4)
                        {
                            debug = 'd4';
                            s = s*1.0/d4;
                            d4 = d4 + 1;
                            if(d4>(a1-i1)) di = 5;
                        }
                        if(di==5)
                        {
                            debug = 'd5';
                            s = s*1.0/d5;
                            d5 = d5 + 1;
                            if(d5>(a2-i2)) di = 6;
                        }
                        if(di==6)
                        {
                            debug = 'd6';
                            s = s*1.0/d6;
                            d6 = d6 + 1;
                            if(d6>(b-i1-i2)) di = 7;
                        }
                        if(di==7)
                        {
                            debug = 'd7';
                            s = s*1.0/d7;
                            d7 = d7 + 1;
                            if(d7>(N-b-a1-a2+i1+i2)) di = 8;
                        }
                    }
                    else if ((s<1 and ui<=5) or di>7)
                    {
                        if(ui==1)
                        {
                            debug = 'u1';
                            s = s*1.0*u1;
                            u1 = u1 + 1;
                            if(u1>b) ui = 2;
                        }
                        if(ui==2)
                        {
                            debug = 'u2';
                            s = s*1.0*u2;
                            u2 = u2 + 1;
                            if(u2>N-b) ui = 3;
                        }
                        if(ui==3)
                        {
                            debug = 'u3';
                            s = s*1.0*u3;
                            u3 = u3 + 1;
                            if(u3>a1) ui = 4;
                        }
                        if(ui==4)
                        {
                            debug = 'u4';
                            s = s*1.0*u4;
                            u4 = u4 + 1;
                            if(u4>a2) ui = 5;
                        }
                        if(ui==5)
                        {
                            debug = 'u5';
                            s = s*1.0*u5;
                            u5 = u5 + 1;
                            if(u5>(N-a1-a2)) ui = 6;
                        }
                    }
                }
                
                if(s<0)
                    s = 0;
                else if(s>1)
                    s = 1;
            }
            P = P-s;
        }
    }
    
    // Make sure that round-off errors never make P greater than 1.
    if(P<0)
        P = 0;
    else if(P>1)
        P = 1;

    return(P);
}



//下面是R脚本程序  
/*** R 
#格式非得这样:/*** R   
#hygecdf2(140,70,5000,3000,150,80) 
*/  