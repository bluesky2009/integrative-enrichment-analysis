function IEA(dataPath, conTrol, data, genecard, ppi, geneset)

    %% Load libs
    addpath('./_Funcs')
   
    %% Load data
    dataFile = [dataPath,'data\',data] % The path of data
    % Load expression data from xls file
    [data, text, alldata] = xlsread(dataFile,'data');
    Mdata = data(:,1:size(data,2)); %�׻������� ���ǻ���
    Mdata = zscore(Mdata')';

    % Load gene name
    [data, text, alldata] = xlsread(dataFile,'geneName');
    genename = text(:,2);%�������֣����ظ���
    genename = genename(1:length(genename),:);
    % Load probe name
    [data, text, alldata] = xlsread(dataFile,'geneName');
    cpg = text(:,1);%�׻���λ������
    cpg = cpg(1:length(cpg),:);
    % Load disease infor.
    [data, text, alldata] = xlsread(dataFile,'disease');
    clinical = text;
    clinical = clinical(:,1:size(clinical,2));

    %% ȥ��û��map�ϵĻ���
    r=[];
    for i=2:length(genename)
        if isempty(genename{i})
            temp=i;
            r=[r;temp];
        end
    end
    genename([r],:)=[];
    Mdata([r],:)=[];
    cpg([r],:)=[];

    %% ȥ��������ȱֵ����
    [nanrow,c]=find(isnan(Mdata));
    if size(nanrow,1)>0
        Mdata([nanrow],:)=[];
        genename([nanrow],:)=[];
        cpg([nanrow],:)=[];
    end

    %% Extract samples in different classes / phenotypes
    class1 = find(~strcmp(clinical(1,:),conTrol));%%disease ��������
    class2 = find(strcmp(clinical(1,:),conTrol));%%control

    %% Load  PPI data 
    [PPi] = PPIloader(dataPath, genename, ppi, 0);

    %% Load list of disease genes
    doFile = [dataPath,'data\',genecard]
    [data, text, alldata] = xlsread(doFile);
    GeneCard = text;
    GeneCards = []; % The genecard genes in data with index
    GeneCardG = []; % The genecard genes in data with name symbol

    for i=1:length(genename)
        hit = find(strcmp(GeneCard(:,1),genename(i)));
        if length(hit)>0
            GeneCards = [GeneCards;i];
            GeneCardG = [GeneCardG;genename(i)];
        end
    end

     %% Load list of pathway genes
    GS = importdata(geneset);
    GSN = {}; % pathway genesets in GSEA with gene symbol
    GSH = {}; % pathway genesets in data with index
    nGSH = []; % The complete list of pathway genes in data
    for i=1:size(GS,1) % Check each pathway infor. from GSEA
        gs = GS(i,:); % A pathway
        
        gsh = [];
        gsn = [];
        for j=1:length(gs)
            g = gs(j); % A gene in pathway
            
            if length(g{1})>0 % Re-store the original genes in pathway
                gsn = [gsn,g];
            end
            
            hit = find(strcmp(genename,g)); % Re-store the original genes in pathway
            if length(hit)>0
                gsh = [gsh,hit];
                nGSH = [nGSH,hit];
            end
        end

        GSN{i}.pathname = gs(1);
        GSN{i}.genes = gsn;
        GSH{i}.pathname = gs(1);
        GSH{i}.genes = gsh;
    end
    nGSH = unique(nGSH);
    
    
    MG = {} % The pathways belonging to a same gene, i.e. a gene's occurance in different pathways
    for i=1:size(genename,1)
        mg = genename(i);
        mgp = [];
        for j=1:size(GS,1)
            gs = GS(j,:);
            hit = find(strcmp(gs,mg));
            if length(hit)>0
                mgp = [mgp,j];
            end
        end
        MG{i}.g = mg;
        MG{i}.p = mgp;
    end
 
    MGN = []; % Counting the number of pathways belonging to a same gene, i.e. a gene's occurance in different pathways
    for i=1:size(genename,1)
        if i==1
            MGN = [MG{i}.g,length(MG{i}.p)];
        else
            MGN = [MGN;[MG{i}.g,length(MG{i}.p)]];
        end
    end
    
    clear A c i nanrow r temp;
    %% Save processed data
    saveFile = [dataPath,'results\WorkData']
    save(saveFile);
            
    %% Load processed data for main analysis
    dataFile = [dataPath,'results\WorkData']

    %% IEA main on each dataset
    % General statistics on DEG & DEVG 
    % DEG: index of DEGs
    % DEVG: index of DEVGs
    % Stat: Stat gives the signficance of overlap among DEGs or DEVGs and pathway 
    % Gname: the list of gene symbols
    % PG_DEG: index of pathway genes in DEGs
    % PG_DEVG: index of pathway genes in DEVGs
    % DG_DEG: index of disease genes in DEGs
    % DG_DEVG: index of disease genes in DEVGs
    % DEGup: index of DEGs with down-regulation in case
    % DEGdown: index of DEGs with up-regulation in case
    % DEVGup: index of DEVGs with tight-regulation in case
    % DEVGdown: index of DEVGs with losse-regulation in case
    % C: (z-socre) data of control samples
    % D: (z-socre) data of case samples
    % tP: P-value of all genes, which determine the DEGs
    % tPa: P-value of all genes, which determine the DEVGs
    [DEG1, DEVG1, Stat1, Gname1, PG_DEG1, PG_DEVG1, DG_DEG1, DG_DEVG1, DEGup1, DEGdown1, DEVGup1, DEVGdown1, C1, D1, tP1, tPa1] = step0statistic(dataFile,dataPath,0.05,0.05);
    
%     Rt = {dataPath,'DEG','DEVG','PG_DEG','DEG_DEG','PG_DEVG','DG_DEVG','DEGup','DEGdown','DEVGup','DEVGdown'};
%     Rt = [Rt; {dataPath,length(DEG1),length(DEVG1), length(PG_DEG1),length(DG_DEG1),length(PG_DEVG1),length(DG_DEVG1),length(DEGup1),length(DEGdown1),length(DEVGup1),length(DEVGdown1)}];
%     dlmcell([dataPath,'R1.txt'],Rt);
%     
    size(DEG1);
    size(DEVG1);
    Rg = {'Gene','Type'}
    for i=1:size(DEG1,2)
        xp = DEG1(1,i);
        Rg = [Rg;[Gname1(xp,1),'DEG']];
    end
    for i=1:size(DEVG1,2)
        xp = DEVG1(1,i);
        Rg = [Rg;[Gname1(xp,1),'DEVG']];
    end
    Rg;
    dlmcell([dataPath,'R1.txt'],Rg);
    
    % Pahtway enrichment in IEA
    [GSP1, check] = step1PG(DEG1,DEVG1,PG_DEG1,PG_DEVG1,dataFile,dataPath);  
    Rg = {'Pathway','HT1','HT2'}
    Rg = [Rg;GSP1(:,[1,2,5])];
    dlmcell([dataPath,'R2_GSP.txt'],Rg);
                    
    % Pathway crosstalk in IEA        
    [PsC1, PSC1, PCN1] = step2PGmkvPsC(PPi,DEG1,DEVG1,PG_DEG1,PG_DEVG1,C1,D1,dataFile,dataPath,0.001);
    Rg = {'Pathway1','Pathway2','Pv'}
    Rg = [Rg;PsC1(:,1:3)];
    dlmcell([dataPath,'R3_1_PSC.txt'],Rg);
    
    Rg = {'Pathway1','Pathway2','Pv1','Pv2'}
    Rg = [Rg;PSC1(:,1:4)];
    dlmcell([dataPath,'R3_2_PsC.txt'],Rg);
   
end
