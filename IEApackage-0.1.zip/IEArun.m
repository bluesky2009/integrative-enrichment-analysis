clc;
clear;

dataPath = '.\10-T2D-pan\';
conTrol = 'status: Non-diabetic donor';
data = 'GSE41762.xlsx';
genecard = 'TD genecards.xlsx';
ppi = 'String_v9.1_hs_900.csv';
geneset = 'c2.cp.kegg.v4.0.symbols.xls';
IEA(dataPath, conTrol, data, genecard, ppi, geneset)