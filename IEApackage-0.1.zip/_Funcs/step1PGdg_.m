% Enrichment of PPI neighbors
function [ GSP, check, PsC ] = step1PGdg(dataFile,dataPath,tP)
       
    mi = 1;
    %% Load processed data
    dataFile;
    load(dataFile) %'.\results\WorkData'    % The whole data matrix

    %% Prepare groups of data and disease labels
    % Remove the gene with missing data
    [nanrow,c] = find(isnan(Mdata));
    Mdata([nanrow],:) = [];
    genename([nanrow],:) = [];
    Zdata = Mdata;
    
    C = Zdata(:,[class2]);% data from control samples[class2]
    D = Zdata(:,[class1]);% data from case samples [class1]
    X = [C,D]; % Reoganized data as [control samples,case samples]
    Lcd = [ones(1,length(class2)), 2*ones(1,length(class1))]; % Class label for accuracy evaluation

    if tP>=1 || tP<=0
        tP = 0.05;  % The threshold of significance test 0.01
    end
   
    %% Load  PPI data 
    % %%%%%%%%%%%%%%%%%%%%%
    %[PPi] = PPIloader(dataPath, genename, 'String_v9.1_hs_900.xlxs', 1);
    [PPi] = PPIloader(dataPath, genename, 'String_v9.1_hs_900.csv', 1);
    
    PsC = 0;
    %[PsC] = PathCross(GSH, PPi)

    % Sparse neighbouring 0-1 matrix
    I = [];
    J = [];
    S = [];
    nodes = keys(PPi);
    for k=1:size(nodes,2)
        node = cell2mat(nodes(k));
        try
            child = PPi(node);
            child = keys(PPi(node));
            
%             for kk=1:length(child)
%                 r1 = node;
%                 r2 = child{kk};
%                 
%                 I = [I,r1];
%                 J = [J,r2];
%                 S = [S,1.0/length(child)];
%             end
            
            sumPCC = 0;
            for kk=1:length(child)
                r11 = node;
                r22 = child{kk};
                
%                 inPath = 0;
%                 for j=1:size(GSH,2)
%                     gs = GSH{j};
%                     gs.genes;
%                         
%                     if sum(find(gs.genes==r11))>0 & sum(find(gs.genes==r22))>0
%                         inPath = 1;
%                         break;
%                     end
%                 end
%                 if inPath==1
%                     continue
%                 end
 
                corr(D(r11,:)',D(r22,:)');
                
                cc = abs(corr(C(r11,:)',C(r22,:)')-corr(D(r11,:)',D(r22,:)'));
                %cc = abs(corr(C(r11,:)',C(r22,:)'));
               % cc = abs(corr(D(r11,:)',D(r22,:)'));
                %cc = 1-mattest(C(r11,:).* C(r22,:), D(r11,:).* D(r22,:)); 
                sumPCC = cc + sumPCC;
            end

            for kk=1:length(child)
                r1 = node;
                r2 = child{kk};
                
%                 inPath = 0;
%                 for j=1:size(GSH,2)
%                     gs = GSH{j};
%                     gs.genes;
%                         
%                     if sum(find(gs.genes==r1))>0 & sum(find(gs.genes==r2))>0
%                         inPath = 1;
%                         break;
%                     end
%                 end
%                 if inPath==1
%                     continue
%                 end
                
                cc = abs(corr(C(r1,:)',C(r2,:)')-corr(D(r1,:)',D(r2,:)'));
                %cc = abs(corr(C(r1,:)',C(r2,:)'));
                %cc = abs(corr(D(r1,:)',D(r2,:)'));
                %cc = 1-mattest(C(r1,:).* C(r2,:), D(r1,:).* D(r2,:)); 
                
                I = [I,r1];
                J = [J,r2];
                S = [S,cc*1.0/sumPCC];
            end
        catch
            err = 'Err'
            continue;
        end
    end
    Mov = sparse(I,J,S,length(genename),length(genename));
    
   %% Get DEGs and DEVGs
    Ndeg = 0;  % The number of DEGs selected
    Ndevg = 0; % The number of DEVGs selected
    
    % Get the DEGs
    p = mattest(C,D);
    trow_ttest = find(p<=tP); % The list of DEGs
    Lttest = []; % The vector of disease genes in DEGs 
    PG_deg = []; % The list of disease genes in DEGs
    for ai=1:size(X,1)
        if p(ai)>tP % Remove genes can selected by T-test
            Lttest = [Lttest, 0];
        else 
            Ndeg = Ndeg + 1;
            
            hit = 0;
            if sum(find(GeneCards==ai))>0
                hit = 1;   
                PG_deg = [PG_deg,ai];
            end    
            Lttest = [Lttest, hit];
        end
    end
   
    % Get the DEVGs
    trow_Attest = []; % The list of DEVGs
    Lattest = []; % The vector of pathway genes in DEVGs 
    PG_devg = []; % The list of pathway genes in DEVGs
    pa = [];
    XF = mean(X')';
    XC = C;
    XD = D;
    for ai=1:size(XF,1)
        XC(ai,:) = abs(XC(ai,:)-XF(ai)).^mi;
        XD(ai,:) = abs(XD(ai,:)-XF(ai)).^mi;
        xp = ranksum(XC(ai,:),XD(ai,:));
        pa = [pa,xp];
        if xp<=tP && p(ai)>tP % Remove genes can selected by T-test
            trow_Attest = [trow_Attest, ai];
            Ndevg = Ndevg + 1;    
            
            hit = 0;
            if sum(find(GeneCards==ai))>0
                hit = 1;   
                PG_devg = [PG_devg,ai];
            end        
            Lattest = [Lattest, hit];
        else
            Lattest = [Lattest, 0];
        end
    end
    check = Lattest;
    
    Lcombine = []; % The list / vector of pathway genes in DEGs and DEVGs
    for i=1:length(Lttest)
        if Lttest(i)+Lattest(i)==0
            Lcombine = [Lcombine,0];
        else
            Lcombine = [Lcombine,1];
        end
    end
      
    ML = [] % The list / vector of all disease genes as background
    PG = [];
    for i=1:length(genename)
        hit = 0;
        if sum(find(GeneCards==i))>0
            PG = [PG,i];
            hit = 1;
        end
        ML = [ML,hit];
    end 
    
    [Ndeg,Ndevg,size(trow_ttest),size(trow_Attest),sum(Lttest),sum(Lattest),length(PG_deg),length(PG_devg), sum(Lcombine),sum(ML)]
    
    %% ROC analysis of enrichment of pahtway genes in selection
    % (A) ROC analysis of all genes based on ranking of P and Pa values
    [pX_p,pY_p,T,AUC_p] = perfcurve(ML,p,'1');
    [pX_pa,pY_pa,T,AUC_pa] = perfcurve(ML,pa,'1');
    
    [pX_deg,pY_deg,T,AUC_deg] = perfcurve(ML(trow_ttest),p(trow_ttest),'1');
    [pX_devg,pY_devg,T,AUC_devg] = perfcurve(ML(trow_Attest),pa(trow_Attest),'1');
    
    inxLttest = setdiff(1:length(ML),PG_deg);
    inxLattest = setdiff(1:length(ML),PG_devg);
    inxCombine = setdiff(setdiff(1:length(ML),PG_deg),PG_devg);
    [pX_degRemain,pY_degRemain,T,AUC_degRemain] = perfcurve(ML(inxLttest),p(inxLttest),'1');
    [pX_devgRemain,pY_devgRemain,T,AUC_devgRemain] = perfcurve(ML(inxLattest),pa(inxLattest),'1');  
    [pX_comBine,pY_comBine,T,AUC_comBine] = perfcurve(ML(inxCombine),pa(inxCombine),'1');  
    
    % Refine the selected genes rooted from selected pathway genes by
    % random walk
    Status = 'Rank'
    lamda = 0.8;
    
    L = Lttest';
    res = 1;
    while res>0.000001
        LL = (1-lamda)*Mov*L+lamda*Lttest';
        res = normest(LL-L);
        L = LL;
    end
    Lttest = L';
   
    L = Lattest';
    res = 1;
    while res>0.000001
        LL = (1-lamda)*Mov*L+lamda*Lattest';
        res = normest(LL-L);
        L = LL;
    end
    Lattest = L';
    
    L = Lcombine';
    res = 1;
    while res>0.000001
        LL = (1-lamda)*Mov*L+lamda*Lcombine';
        res = normest(LL-L);
        L = LL;
    end
    Lcombine = L';
    
    inxLttest = setdiff(1:length(ML),PG_deg);
    inxLattest = setdiff(1:length(ML),PG_devg);
    inxCombine = setdiff(setdiff(1:length(ML),PG_deg),PG_devg);
    [pX_degRemainRS,pY_degRemainRS,T,AUC_degRemainRS] = perfcurve(ML(inxLttest),Lttest(inxLttest),'1');
    [pX_devgRemainRS,pY_devgRemainRS,T,AUC_devgRemainRS] = perfcurve(ML(inxLattest),Lattest(inxLattest),'1');  
    [pX_comBineRS,pY_comBineRS,T,AUC_comBineRS] = perfcurve(ML(inxCombine),Lcombine(inxCombine),'1');      
    
    
    [sL, inxLttest] = sort(Lttest,'descend');
    [sL, inxLattest] = sort(Lattest,'descend');
    [sL, inxCombine] = sort(Lcombine,'descend');
    inxLttest = inxLttest(1:(Ndeg));
    inxLattest = inxLattest(1:(Ndevg));
    inxCombine = inxCombine(1:(Ndevg+Ndeg));
    inxLttest = setdiff(inxLttest,PG_deg);
    inxLattest = setdiff(inxLattest,PG_devg);
    inxCombine = setdiff(setdiff(inxCombine,PG_deg),PG_devg);   
    
    PG_degRS = intersect(inxLttest,PG);
    PG_devgRS = intersect(inxLattest,PG);
    PG_comRS = intersect(inxCombine,PG); 
       
    [AUC_p,AUC_pa]
    [AUC_deg,AUC_devg]
    [AUC_p,AUC_deg]
    [AUC_pa,AUC_devg]
    [AUC_degRemain,AUC_degRemainRS]
    [AUC_devgRemain,AUC_devgRemainRS]
    [AUC_comBine,AUC_comBineRS]
    [length(PG_degRS),length(PG_devgRS),length(PG_comRS)]
    
    GSP = {};
end

