%% Select genes with PV < tP (0.05 as default), 
%% so that different methods will get different numbers of genes for clustering
function [ DGp ] = step0statisticDGpath(GS,GeneCard,genename)
        
    GSH = GS;
    GeneCards = GeneCard(:,1);
    
    DGP = [];
    Status = 'Screening pathway'
    for i=1:size(GSH,2)
        gs = GSH{i};
        gs.pathname;
        gs.genes;
        
        hits = intersect(gs.genes,GeneCards);
            
        if length(DGP)==0
            DGP = [gs.pathname,length(hits),length(genename),length(GeneCards),length(gs.genes),1-hygecdf(length(hits),length(genename),length(GeneCards),length(gs.genes))];
        else
            DGP = [DGP;[gs.pathname,length(hits),length(genename),length(GeneCards),length(gs.genes),1-hygecdf(length(hits),length(genename),length(GeneCards),length(gs.genes))]];
        end
    end    
    
    DGp = DGP;
    
end