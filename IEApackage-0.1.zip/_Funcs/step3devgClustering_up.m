%% Select genes with PV < tP (0.05 as default), 
%% so that different methods will get different numbers of genes for clustering
function [ SPC_up,SPC_DEVG_up] = step3devgClustering_up(DEG,DEVG,DEGup,DEGdown,DEVGup,DEVGdown,C,D,dataFile,dataPath,tP)
        
    mi = 1;
    %% Load processed data
    dataFile;
    load(dataFile) %'.\results\WorkData'    % The whole data matrix

    XF = mean(D')';
    XC = C;
    for ai=1:size(XF,1)
        for aj=1:size(XC,2)
            if XC(ai,aj)>=XF(ai)
                XC(ai,aj)=1;
            else
                XC(ai,aj)=0;
            end
        end
    end

    XF = mean(C')';
    XD = D;
    for ai=1:size(XF,1)
        for aj=1:size(XD,2)
            if XD(ai,aj)>=XF(ai)
                XD(ai,aj)=1;
            else
                XD(ai,aj)=0;
            end
        end
    end
    
    trow_ttest = DEG;
    trow_Attest = DEVG;
    trow_devg_C = DEVGup;
    trow_devg_D = DEVGdown;
    
    size(trow_ttest)
    size(trow_Attest)
    size(trow_devg_C)
    size(trow_devg_D)
    
    %%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    SPC_up = {'Pathway','sex_devg_raw','age_devg_raw','bmi_devg_raw','Hba_devg_raw','sex_devg_rel','age_devg_rel','bmi_devg_rel','Hba_devg_rel','sex_path','age_path','bmi_path','Hba_path'};
   
    Status = 'Screening pathway'
    for i=1:size(GSH,2) % Scan each pathway
        gs = GSH{i};
        gs.pathname;
        gs.genes;
        
        hits = intersect(gs.genes,trow_devg_C);
       
        if length(hits)>0
            P_devg_C = C(gs.genes,:); % The pathway gene profile in control
            C_devg_C = C(hits,:); % The feature gene original profile in control
            XC_devg_C = XC(hits,:); % The feature gene DEVG profile in controal
            
            Sex_C;
            Sex_D;
            Age_C;
            Age_D;
            Bmi_C;
            Bmi_D;
            Hba_C;
            Hba_D;
            
            % Check pathways by their original profiles
            V = find(Sex_C>-1);
            CX = C_devg_C(:,V);
            CL = Sex_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P1,CI] = ttest2(CL(C1),CL(C2));
            
            V = find(Age_C>-1);
            CX = C_devg_C(:,V);
            CL = Age_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P2,CI] = ttest2(CL(C1),CL(C2));           

            % Get valid samples
            V = find(Bmi_C>-1);
            % Get valid data
            CX = C_devg_C(:,V); % Expression 
            CL = Bmi_C(V); % Clinic
            % Clustering
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            % Check significance
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P3,CI] = ttest2(CL(C1),CL(C2));       
            
            V = find(Hba_C>-1);
            CX = C_devg_C(:,V);
            CL = Hba_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P4,CI] = ttest2(CL(C1),CL(C2));   
            
            
            % Check pathways by their DEVG profiles
            V = find(Sex_C>-1);
            CX = XC_devg_C(:,V);
            CL = Sex_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P5,CI] = ttest2(CL(C1),CL(C2));
            
            V = find(Age_C>-1);
            CX = XC_devg_C(:,V);
            CL = Age_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P6,CI] = ttest2(CL(C1),CL(C2));           

            V = find(Bmi_C>-1);
            CX = XC_devg_C(:,V);
            CL = Bmi_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P7,CI] = ttest2(CL(C1),CL(C2));       
            
            V = find(Hba_C>-1);
            CX = XC_devg_C(:,V);
            CL = Hba_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P8,CI] = ttest2(CL(C1),CL(C2));  
            
            % Check pathways by their gene profiles
            V = find(Sex_C>-1);
            CX = P_devg_C(:,V);
            CL = Sex_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P9,CI] = ttest2(CL(C1),CL(C2));
            
            V = find(Age_C>-1);
            CX = P_devg_C(:,V);
            CL = Age_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P10,CI] = ttest2(CL(C1),CL(C2));           

            V = find(Bmi_C>-1);
            CX = P_devg_C(:,V);
            CL = Bmi_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P11,CI] = ttest2(CL(C1),CL(C2));       
            
            V = find(Hba_C>-1);
            CX = P_devg_C(:,V);
            CL = Hba_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P12,CI] = ttest2(CL(C1),CL(C2));  
            

            SPC_up = [SPC_up;{gs.pathname,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12}];
        end
    end    
 
    SPC_DEVG_up = {'Devg','sex_devg_raw','age_devg_raw','bmi_devg_raw','Hba_devg_raw','sex_devg_rel','age_devg_rel','bmi_devg_rel','Hba_devg_rel'};
   
    Status = 'Screening DEVG'
    for i=1:length(DEVGup) % Scan each pathway
        g = DEVGup(i);
               
        if i>0
            C_devg_C = C(g,:); % The feature gene original profile in control
            XC_devg_C = XC(g,:); % The feature gene DEVG profile in controal
            
            Sex_C;
            Sex_D;
            Age_C;
            Age_D;
            Bmi_C;
            Bmi_D;
            Hba_C;
            Hba_D;
            
            % Check pathways by their original profiles
            V = find(Sex_C>-1);
            CX = C_devg_C(:,V);
            CL = Sex_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P1,CI] = ttest2(CL(C1),CL(C2));
            
            V = find(Age_C>-1);
            CX = C_devg_C(:,V);
            CL = Age_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P2,CI] = ttest2(CL(C1),CL(C2));           

            % Get valid samples
            V = find(Bmi_C>-1);
            % Get valid data
            CX = C_devg_C(:,V); % Expression 
            CL = Bmi_C(V); % Clinic
            % Clustering
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            % Check significance
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P3,CI] = ttest2(CL(C1),CL(C2));       
            
            V = find(Hba_C>-1);
            CX = C_devg_C(:,V);
            CL = Hba_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P4,CI] = ttest2(CL(C1),CL(C2));   
            
            
            % Check pathways by their DEVG profiles
            V = find(Sex_C>-1);
            CX = XC_devg_C(:,V);
            CL = Sex_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P5,CI] = ttest2(CL(C1),CL(C2));
            
            V = find(Age_C>-1);
            CX = XC_devg_C(:,V);
            CL = Age_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P6,CI] = ttest2(CL(C1),CL(C2));           

            V = find(Bmi_C>-1);
            CX = XC_devg_C(:,V);
            CL = Bmi_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P7,CI] = ttest2(CL(C1),CL(C2));       
            
            V = find(Hba_C>-1);
            CX = XC_devg_C(:,V);
            CL = Hba_C(V);
            CY = pdist(CX', 'euclid');
            CZ = linkage(CY, 'average');
            CT = cluster(CZ, 'maxclust',2);
            C1 = find(CT==1);
            C2 = find(CT==2);
            [H,P8,CI] = ttest2(CL(C1),CL(C2));  
                                   
            SPC_DEVG_up = [SPC_DEVG_up;{genename(g),P1,P2,P3,P4,P5,P6,P7,P8}];
        end
    end    
    
end