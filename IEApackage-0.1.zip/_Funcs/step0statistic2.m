% Check the robustness of HT and IEA in replicate datasets 
function [ RB,PB1,PB2,PB3,PB4 ] = step0statistic2( Gname1,Gname2,DEG1,DEVG1,DEG2,DEVG2,PG_DEG1,PG_DEG2, PG_DEVG1,PG_DEVG2,DG_DEG1,DG_DEG2,DG_DEVG1,DG_DEVG2, DEGup1, DEGdown1, DEVGup1, DEVGdown1, DEGup2, DEGdown2, DEVGup2, DEVGdown2,GSP1,GSP2,dataPath )
%STEP0STATISTIC2 Summary of this function goes here
%   Detailed explanation goes here

    Rp = {};
    Status = 'DEG & DEVG'
    deg1 = Gname1(DEG1);
    devg1 = Gname1(DEVG1);
    deg2 = Gname2(DEG2);
    devg2 = Gname2(DEVG2);
    [[length(deg1),length(deg2),length(intersect(deg1,deg2))],1-hygecdf(length(intersect(deg1,deg2)),max(length(Gname1),length(Gname2)),length(deg1),length(deg2))]
    [[length(devg1),length(devg2),length(intersect(devg1,devg2))],1-hygecdf(length(intersect(devg1,devg2)),max(length(Gname1),length(Gname2)),length(devg1),length(devg2))]
    [[length(deg1),length(devg2),length(intersect(deg1,devg2))],1-hygecdf(length(intersect(deg1,devg2)),max(length(Gname1),length(Gname2)),length(deg1),length(devg2))]
    [[length(deg2),length(devg1),length(intersect(deg2,devg1))],1-hygecdf(length(intersect(deg2,devg1)),max(length(Gname1),length(Gname2)),length(deg2),length(devg1))]
    Rp = [Rp,1-hygecdf(length(intersect(deg1,deg2)),max(length(Gname1),length(Gname2)),length(deg1),length(deg2))];
    Rp = [Rp,1-hygecdf(length(intersect(devg1,devg2)),max(length(Gname1),length(Gname2)),length(devg1),length(devg2))];
    
    Status = 'PG of DEG & DEVG'
    deg1 = Gname1(PG_DEG1);
    devg1 = Gname1(PG_DEVG1);
    deg2 = Gname2(PG_DEG2);
    devg2 = Gname2(PG_DEVG2);
    [[length(deg1),length(deg2),length(intersect(deg1,deg2))],1-hygecdf(length(intersect(deg1,deg2)),max(length(Gname1),length(Gname2)),length(deg1),length(deg2))]
    [[length(devg1),length(devg2),length(intersect(devg1,devg2))],1-hygecdf(length(intersect(devg1,devg2)),max(length(Gname1),length(Gname2)),length(devg1),length(devg2))]
    [[length(deg1),length(devg2),length(intersect(deg1,devg2))],1-hygecdf(length(intersect(deg1,devg2)),max(length(Gname1),length(Gname2)),length(deg1),length(devg2))]
    [[length(deg2),length(devg1),length(intersect(deg2,devg1))],1-hygecdf(length(intersect(deg2,devg1)),max(length(Gname1),length(Gname2)),length(deg2),length(devg1))]
    Rp = [Rp,1-hygecdf(length(intersect(deg1,deg2)),max(length(Gname1),length(Gname2)),length(deg1),length(deg2))];
    Rp = [Rp,1-hygecdf(length(intersect(devg1,devg2)),max(length(Gname1),length(Gname2)),length(devg1),length(devg2))];
    
    Status = 'DG of DEG & DEVG'
    deg1 = Gname1(DG_DEG1);
    devg1 = Gname1(DG_DEVG1);
    deg2 = Gname2(DG_DEG2);
    devg2 = Gname2(DG_DEVG2);
    [[length(deg1),length(deg2),length(intersect(deg1,deg2))],1-hygecdf(length(intersect(deg1,deg2)),max(length(Gname1),length(Gname2)),length(deg1),length(deg2))]
    [[length(devg1),length(devg2),length(intersect(devg1,devg2))],1-hygecdf(length(intersect(devg1,devg2)),max(length(Gname1),length(Gname2)),length(devg1),length(devg2))]
    [[length(deg1),length(devg2),length(intersect(deg1,devg2))],1-hygecdf(length(intersect(deg1,devg2)),max(length(Gname1),length(Gname2)),length(deg1),length(devg2))]
    [[length(deg2),length(devg1),length(intersect(deg2,devg1))],1-hygecdf(length(intersect(deg2,devg1)),max(length(Gname1),length(Gname2)),length(deg2),length(devg1))]
    Rp = [Rp,1-hygecdf(length(intersect(deg1,deg2)),max(length(Gname1),length(Gname2)),length(deg1),length(deg2))];
    Rp = [Rp,1-hygecdf(length(intersect(devg1,devg2)),max(length(Gname1),length(Gname2)),length(devg1),length(devg2))];
    
    deg1 = Gname1(DEGup1);
    deg2 = Gname2(DEGup2);  
    Rp = [Rp,1-hygecdf(length(intersect(deg1,deg2)),max(length(Gname1),length(Gname2)),length(deg1),length(deg2))];
    deg1 = Gname1(DEGdown1);
    deg2 = Gname2(DEGdown2);  
    Rp = [Rp,1-hygecdf(length(intersect(deg1,deg2)),max(length(Gname1),length(Gname2)),length(deg1),length(deg2))];
 
    devg1 = Gname1(DEVGup1);
    devg2 = Gname2(DEVGup2);  
    Rp = [Rp,1-hygecdf(length(intersect(devg1,devg2)),max(length(Gname1),length(Gname2)),length(devg1),length(devg2))];
    devg1 = Gname1(DEVGdown1);
    devg2 = Gname2(DEVGdown2);  
    Rp = [Rp,1-hygecdf(length(intersect(devg1,devg2)),max(length(Gname1),length(Gname2)),length(devg1),length(devg2))];
       
    
    Rt = {'DEG','DEVG','PG_DEG','PG_DEVG','DG_DEG','DG_DEVG','DEGup','DEGdown','DEVGup','DEVGdown'};
    Rt = [Rt; {length(intersect(Gname1(DEG1),Gname2(DEG2))),length(intersect(Gname1(DEVG1),Gname2(DEVG2))), length(intersect(Gname1(PG_DEG1),Gname2(PG_DEG2))),length(intersect(Gname1(PG_DEVG1),Gname2(PG_DEVG2))),length(intersect(Gname1(DG_DEG1),Gname2(DG_DEG2))),length(intersect(Gname1(DG_DEVG1),Gname2(DG_DEVG2))),length(intersect(Gname1(DEGup1),Gname2(DEGup2))),length(intersect(Gname1(DEGdown1),Gname2(DEGdown2))),length(intersect(Gname1(DEVGup1),Gname2(DEVGup2))),length(intersect(Gname1(DEVGdown1),Gname2(DEVGdown2)))}];
    Rt = [Rt; Rp];
    dlmcell([dataPath,'R1_1.txt'],Rt);
        
    Status = 'Robustness...'

    [sL, inx1] = sort(cell2mat(GSP1(:,2)));
    [sL, inx1_1] = sort(cell2mat(GSP1(:,3)));
    [sL, inx1_2] = sort(cell2mat(GSP1(:,4)));
    [sL, inx1_3] = sort(cell2mat(GSP1(:,5)));
    [sL, inx2] = sort(cell2mat(GSP2(:,2)));
    [sL, inx2_1] = sort(cell2mat(GSP2(:,3)));
    [sL, inx2_2] = sort(cell2mat(GSP2(:,4)));
    [sL, inx2_3] = sort(cell2mat(GSP2(:,5)));
    
    % The significance of re-observed pathways in two datasets
    RB = {};
    for k=1:size(GSP1,1)
        OP1 = intersect(inx1(1:k),inx2(1:k));
        OP2 = intersect(inx1_1(1:k),inx2_1(1:k));
        OP3 = intersect(inx1_2(1:k),inx2_2(1:k));
        OP4 = intersect(inx1_3(1:k),inx2_3(1:k));
        RB = [RB;{k,length(OP1),length(OP2),length(OP3),length(OP4),(1-hygecdf(length(OP1),size(GSP1,1),k,k)),(1-hygecdf(length(OP2),size(GSP1,1),k,k)),(1-hygecdf(length(OP3),size(GSP1,1),k,k)),(1-hygecdf(length(OP4),size(GSP1,1),k,k))}]; %,OverlapP(length(OP),size(GSP1,1),k,k)
    end
    RB;
    PB1 = GSP1(intersect(inx1(1:30),inx2(1:30)),:);
    PB2 = GSP1(intersect(inx1_1(1:30),inx2_1(1:30)),:);
    PB3 = GSP1(intersect(inx1_2(1:30),inx2_2(1:30)),:);
    PB4 = GSP1(intersect(inx1_3(1:30),inx2_3(1:30)),:);
    
    OT = {'K','DEG','DEVG','CDD','IDD','pDEG','pDEVG','pCDD','pIDD'};
    size(OT)
    size(RB)
    OT = [OT;RB];
    OT
    dlmcell([dataPath,'R2_2_RB.txt'],OT);    
    
    
    Rank = {};
    for k=1:size(GSP1,1)
        r1 = find(inx1==k);
        r2 = find(inx1_1==k);
        r3 = find(inx1_2==k);
        r4 = find(inx1_3==k);
        r5 = find(inx2==k);
        r6 = find(inx2_1==k);
        r7 = find(inx2_2==k);
        r8 = find(inx2_3==k);
        Rank = [Rank;{GSP1(k,1),r1,r2,r3,r4,r5,r6,r7,r8}];
    end
    dlmcell([dataPath,'R2_3_Rank.txt'],Rank);  
 
    H = figure();
    set(gcf,'Position',[0 0 910 385]);
    %set(gcf, 'PaperPositionMode', 'auto')
    %set(gcf, 'PaperPositionMode', 'auto');
    
    % Draw the distirbution of pathways
    vGSP1 = cell2mat(GSP1(:,2:11));
    vGSP2 = cell2mat(GSP2(:,2:11));
    
    XY = [];
    for k=1:size(GSP1,1)
        XY = [XY;[vGSP1(k,6)*1.0/vGSP1(k,5),vGSP1(k,7)*1.0/vGSP1(k,5)]];
    end

    subplot(2,4,1)
    plot(XY(inx1(31:length(inx1)),1),XY(inx1(31:length(inx1)),2),'b*');
    %xlabel('This is xlabel','Rotation',15,'fontsize',20)
    hold on;
    plot(XY(inx1(1:30),1),XY(inx1(1:30),2),'r*');
    xlabel('Ratio of DEGs');
    ylabel('Ratio of DEVGs');
    title('(A)');
    subplot(2,4,2)
    plot(XY(inx1_1(31:length(inx1_1)),1),XY(inx1_1(31:length(inx1_1)),2),'b*');
    hold on;
    plot(XY(inx1_1(1:30),1),XY(inx1_1(1:30),2),'r*');
    xlabel('Ratio of DEGs');
    ylabel('Ratio of DEVGs');
    title('(B)');
    subplot(2,4,3)
    plot(XY(inx1_2(31:length(inx1_2)),1),XY(inx1_2(31:length(inx1_2)),2),'b*');
    hold on;
    plot(XY(inx1_2(1:30),1),XY(inx1_2(1:30),2),'r*');
    xlabel('Ratio of DEGs');
    ylabel('Ratio of DEVGs');
    title('(C)');
    subplot(2,4,4)
    plot(XY(inx1_3(31:length(inx1_3)),1),XY(inx1_3(31:length(inx1_3)),2),'b*');
    hold on;
    plot(XY(inx1_3(1:30),1),XY(inx1_3(1:30),2),'r*');
    xlabel('Ratio of DEGs');
    ylabel('Ratio of DEVGs');
    title('(D)');

    XY = [];
    for k=1:size(GSP2,1)
        XY = [XY;[vGSP2(k,6)*1.0/vGSP2(k,5),vGSP2(k,7)*1.0/vGSP2(k,5)]];
    end

    subplot(2,4,5)
    plot(XY(inx2(31:length(inx2)),1),XY(inx2(31:length(inx2)),2),'b*');
    hold on;
    plot(XY(inx2(1:30),1),XY(inx2(1:30),2),'r*');
    xlabel('Ratio of DEGs');
    ylabel('Ratio of DEVGs');
    title('(E)');
    subplot(2,4,6)
    plot(XY(inx2_1(31:length(inx2_1)),1),XY(inx2_1(31:length(inx2_1)),2),'b*');
    hold on;
    plot(XY(inx2_1(1:30),1),XY(inx2_1(1:30),2),'r*');
    xlabel('Ratio of DEGs');
    ylabel('Ratio of DEVGs');
    title('(F)');
    subplot(2,4,7)
    plot(XY(inx2_2(31:length(inx2_2)),1),XY(inx2_2(31:length(inx2_2)),2),'b*');
    hold on;
    plot(XY(inx2_2(1:30),1),XY(inx2_2(1:30),2),'r*');
    xlabel('Ratio of DEGs');
    ylabel('Ratio of DEVGs');
    title('(G)');
    subplot(2,4,8)
    plot(XY(inx2_3(31:length(inx2_3)),1),XY(inx2_3(31:length(inx2_3)),2),'b*');
    hold on;
    plot(XY(inx2_3(1:30),1),XY(inx2_3(1:30),2),'r*');
    xlabel('Ratio of DEGs');
    ylabel('Ratio of DEVGs');
    title('(H)');
    
    set(gcf,'PaperPositionMode','auto')
    %saveas(gcf, 'Figure R2_1', 'pdf'); 
    print(H, '-dpdf', [dataPath,'//Figure R2_1.pdf']);
       
end

