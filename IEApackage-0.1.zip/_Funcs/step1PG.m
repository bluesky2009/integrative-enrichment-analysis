% Enrichment of IEA
function [ GSP, check] = step1PG(DEG,DEVG,PG_DEG,PG_DEVG,dataFile,dataPath)
       
    Func = 'step1PG'
    
%     mi = 1;
%     %% Load processed data
    dataFile;
    load(dataFile) %'.\results\WorkData'    % The whole data matrix
% 
%     %% Prepare groups of data and disease labels
%     % Remove the gene with missing data
%     [nanrow,c] = find(isnan(Mdata));
%     Mdata([nanrow],:) = [];
%     genename([nanrow],:) = [];
%     Zdata = Mdata;
%     
%     C = Zdata(:,[class2]);% data from control samples[class2]
%     D = Zdata(:,[class1]);% data from case samples [class1]
%     X = [C,D]; % Reoganized data as [control samples,case samples]
%     Lcd = [ones(1,length(class2)), 2*ones(1,length(class1))]; % Class label for accuracy evaluation
% 
%     if tP>=1 || tP<=0
%         tP = 0.05;  % The threshold of significance test 0.01
%     end
%     if tPa>=1 || tPa<=0
%         tPa = 0.05;  % The threshold of significance test 0.01
%     end
    
   %% Get DEGs and DEVGs
    Ndeg = length(DEG);  % The number of DEGs selected
    Ndevg = length(DEVG); % The number of DEVGs selected
    
%     % Get the DEGs
%     p = mattest(C,D);
% %     [fdr_p, q] = mafdr(p);
% %     p = fdr_p;
    
    trow_ttest = DEG; % The list of DEGs
    PG_deg = PG_DEG; % The list of pathway genes in DEGs
%     for ai=1:size(X,1)
%         if p(ai)>tP % Remove genes can selected by T-test
%             continue;
%         else 
%             Ndeg = Ndeg + 1;
%             
%             hit = 0;
%             for j=1:size(GSH,2)
%                 gs = GSH{j};
%                 gs.genes;
%                         
%                 if sum(find(gs.genes==ai))>0
%                     hit = 1;   
%                     PG_deg = [PG_deg,ai];
%                     break;
%                 end
%             end          
%         end
%     end
   
    % Get the DEVGs
    trow_Attest = DEVG; % The list of DEVGs
    PG_devg = PG_DEVG; % The list of pathway genes in DEVGs
%     pa = [];
%     XF = mean(X')';
%     XC = C;
%     XD = D;
%     for ai=1:size(XF,1)
%         XC(ai,:) = abs(XC(ai,:)-XF(ai)).^mi;
%         XD(ai,:) = abs(XD(ai,:)-XF(ai)).^mi;
%         xp = ranksum(XC(ai,:),XD(ai,:));
%         pa = [pa,xp];
%     end
%     pa;
% %     [fdr_p, q] = mafdr(pa);
% %     pa = fdr_p
%     
%     for ai=1:size(XF,1)   
%         xp = pa(ai);
%         if xp<=tPa && p(ai)>tP % Remove genes can selected by T-test
%             trow_Attest = [trow_Attest, ai];
%             Ndevg = Ndevg + 1;    
%             
%             hit = 0;
%             for j=1:size(GSH,2)
%                 gs = GSH{j};
%                 gs.genes;
%                         
%                 if sum(find(gs.genes==ai))>0
%                     hit = 1;
%                     PG_devg = [PG_devg,ai];
%                     break;
%                 end
%             end         
%         end
%     end
    
    %% Enrichment score calculation

    GSP = [];
    for i=1:size(GSH,2)
        i
        gs = GSH{i};
        gs.pathname;
        gs.genes;
        
        gs.genes;
        PG_deg;
        intersect(gs.genes,DEG);
        intersect(gs.genes,PG_DEG);
        
        
        hits1 = intersect(gs.genes,PG_deg);
        degP = 1-hygecdf(size(hits1,2), length(genename), size(gs.genes,2), length(trow_ttest)); %size(nodes,2)
        
        hits2 = intersect(gs.genes,PG_devg);
        devgP = 1-hygecdf(size(hits2,2), length(genename), size(gs.genes,2), length(trow_Attest));
        
        hits3 = union(hits1,hits2);
        comP = 1-hygecdf(size(hits3,2), length(genename), size(gs.genes,2), length(trow_ttest)+length(trow_Attest));
        
        twoP = hygecdf2(size(hits1,2),size(hits2,2), length(genename), size(gs.genes,2), length(trow_ttest), length(trow_Attest))
        
        if i==1
            GSP = [gs.pathname,degP,devgP,comP,twoP,size(gs.genes,2),size(hits1,2),size(hits2,2),size(hits3,2), length(trow_ttest), length(trow_Attest)];
        else
            GSP = [GSP;[gs.pathname,degP,devgP,comP,twoP,size(gs.genes,2),size(hits1,2),size(hits2,2),size(hits3,2), length(trow_ttest), length(trow_Attest)]];
        end
    end   

    check = [];
end

