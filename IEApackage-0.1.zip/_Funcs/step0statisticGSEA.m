% Input
% GSP1
% GSP2
% file1: GSEA results 
% file2: GSEA results
function [ ] = step0statisticGSEA(GSP1,GSP2, file1, file2, dataPath)
%   Detailed explanation goes here
    gsea1 = [];
    gsea2 = [];
    
    % Load the results from GSEA 
    [data, text, alldata] = xlsread(file1,'gsea');
    data;
    text = text(2:size(text,1),1);
    data
    length(data)
    text
    length(text)
    
    for i=1:size(GSP1,1) % Scan each pathway for its enrichment in GSEA
        pn = GSP1(i,1);
        
        hit = find(strcmp(text,pn{1}));
        
        if(sum(hit)==0)
            gsea1 = [gsea1,1];
        else
            gsea1 = [gsea1,data(hit)];
        end
    end
    
    [data, text, alldata] = xlsread(file2,'gsea');
    data;
    text = text(2:size(text,1),1);
    
    for i=1:size(GSP2,1)
        pn = GSP2(i,1);
        hit = find(strcmp(text,pn{1}));
        
        if(sum(hit)==0)
            gsea2 = [gsea2,1];
        else
            gsea2 = [gsea2,data(hit)];
        end
    end
    
    [sL, inx1] = sort(gsea1);
    [sL, inx2] = sort(gsea2);
    
    % The significance of re-observed pathways in two datasets
    RB = [];
    for k=1:size(GSP1,1)
        OP = intersect(inx1(1:k),inx2(1:k));
        RB = [RB;[k,length(OP),(1-hygecdf(length(OP),size(GSP1,1),k,k))]]; %,OverlapP(length(OP),size(GSP1,1),k,k)
    end
    RB

    H = figure();
    set(gcf,'Position',[0 0 200 385]);
    
    % Draw the distirbution of pathways
    vGSP1 = cell2mat(GSP1(:,2:11));
    vGSP2 = cell2mat(GSP2(:,2:11));
    
    XY = []; % Ratio of DEGs and DEVGs in a pathway
    for k=1:size(GSP1,1)
        XY = [XY;[vGSP1(k,6)*1.0/vGSP1(k,5),vGSP1(k,7)*1.0/vGSP1(k,5)]];
    end

    subplot(2,1,1)
    plot(XY(inx1(31:length(inx1)),1),XY(inx1(31:length(inx1)),2),'b*');
    hold on;
    plot(XY(inx1(1:30),1),XY(inx1(1:30),2),'r*');
    xlabel('Ratio of DEGs');
    ylabel('Ratio of DEVGs');
    title('(A)');

    XY = [];
    for k=1:size(GSP2,1)
        XY = [XY;[vGSP2(k,6)*1.0/vGSP2(k,5),vGSP2(k,7)*1.0/vGSP2(k,5)]];
    end

    subplot(2,1,2)
    plot(XY(inx2(31:length(inx2)),1),XY(inx2(31:length(inx2)),2),'b*');
    hold on;
    plot(XY(inx2(1:30),1),XY(inx2(1:30),2),'r*');
    xlabel('Ratio of DEGs');
    ylabel('Ratio of DEVGs');
    title('(B)');

    set(gcf,'PaperPositionMode','auto')
    %saveas(gcf, 'Figure R2_1', 'pdf'); 
    print(H, '-dpdf', [dataPath,'//Figure R1_0.pdf']);
       
%     
end

