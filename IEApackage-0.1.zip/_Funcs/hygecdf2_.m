function P = hygecdf2(k1,k2,N,b,a1,a2)

    P = 1;
    for i1=1:k1
        for i2=1:a2
            U = [];
            D = [];
            for i=1:b
                U = [U,i];
            end
            for i=1:(N-b)
                U = [U,i];
            end
            for i=1:a1
                U = [U,i];
            end
            for i=1:a2
                U = [U,i];
            end
            for i=1:(N-a1-a2)
                U = [U,i];
            end
            
            for i=1:N
                D = [D,i];
            end
            for i=1:i1
                D = [D,i];
            end
            for i=1:i2
                D = [D,i];
            end
            for i=1:(a1-i1)
                D = [D,i];
            end
            for i=1:(a2-i2)
                D = [D,i];
            end
            for i=1:(b-i1-i2)
                D = [D,i];
            end
            for i=1:(N-b-a1-a2+i1+i2)
                D = [D,i];
            end

            
            s = 1;
            ui=1;
            di=1;
            while(ui<=size(U,2) || di<=size(D,2))
                if ((s>=1 && di<=size(D,2)) || ui>size(U,2))
                    s = s*1.0/D(di);
                    di = di + 1;
                elseif ((s<1 && ui<=size(U,2)) || di>size(D,2))
                    s = s*1.0*U(ui);
                    ui = ui + 1;
                end
                [s,ui,di,size(U,2),size(D,2)];
            end
            s;
             
            
            P = P-s;
        end
    end

    for i1=(k1+1):a1
        for i2=1:k2
            U = [];
            D = [];
            for i=1:b
                U = [U,i];
            end
            for i=1:(N-b)
                U = [U,i];
            end
            for i=1:a1
                U = [U,i];
            end
            for i=1:a2
                U = [U,i];
            end
            for i=1:(N-a1-a2)
                U = [U,i];
            end
            
            for i=1:N
                D = [D,i];
            end
            for i=1:i1
                D = [D,i];
            end
            for i=1:i2
                D = [D,i];
            end
            for i=1:(a1-i1)
                D = [D,i];
            end
            for i=1:(a2-i2)
                D = [D,i];
            end
            for i=1:(b-i1-i2)
                D = [D,i];
            end
            for i=1:(N-b-a1-a2+i1+i2)
                D = [D,i];
            end

            
            s = 1;
            ui=1;
            di=1;
            while(ui<=size(U,2) || di<=size(D,2))
                if ((s>=1 && di<=size(D,2)) || ui>size(U,2))
                    s = s*1.0/D(di);
                    di = di + 1;
                elseif ((s<1 && ui<=size(U,2)) || di>size(D,2))
                    s = s*1.0*U(ui);
                    ui = ui + 1;
                end
                [s,ui,di,size(U,2),size(D,2)];
            end
            s;
             
            
            P = P-s;
        end
    end
    
    % Make sure that round-off errors never make P greater than 1.
    if(P<0)
        P = 0;
    elseif(P>1)
        P = 1;
    end
end