function [PPi] = PPIloader(dataPath, genename, file, reload )
%PPILOADER Summary of this function goes here
%   Detailed explanation goes here
    if reload == 0 && exist([dataPath, 'results\PPI.mat'], 'file') == 2
        Status = 'Load existing PPI'
        load([dataPath, 'results\PPI'])
    else
        Status = 'Load PPI'
        studygene = genename;
        fid = fopen(file);
        out = textscan(fid,'%s%s','delimiter',',');
        fclose(fid);
        H = [out{1},out{2}];
        %
        PPI = containers.Map('KeyType','char', 'ValueType','any');   % name list
        PPi = containers.Map('KeyType','double', 'ValueType','any'); % id list
        % % Only use the edge in PPI whose two genes are in the expression data
        n=0;  
        for i=1:length(H)
            node1 = H{i,1};
            node2 = H{i,2};
            try
                child = PPI(node1);
                child(node2) = 1;
                PPI(node1) = child;
            catch
                child = containers.Map('KeyType','char', 'ValueType','any');
                child(node2) = 1;
                PPI(node1) = child;
            end

            try
                child = PPI(node2);
                child(node1) = 1;
                PPI(node2) = child;
            catch
                child = containers.Map('KeyType','char', 'ValueType','any');
                child(node1) = 1;
                PPI(node2) = child;
            end

            flag1 = strmatch(node1,studygene,'exact'); 
            flag2 = strmatch(node2,studygene,'exact');

            if flag1 == flag2
                continue
            end

            if size(flag1,1)>0 && size(flag2,1)>0
                try
                    child = PPi(flag1);
                    child(flag2) = 1;
                    PPi(flag1) = child;
                catch
                    child = containers.Map('KeyType','double', 'ValueType','any');
                    child(flag2) = 1;
                    PPi(flag1) = child;
                end

                try
                    child = PPi(flag2);
                    child(flag1) = 1;
                    PPi(flag2) = child;
                catch
                    child = containers.Map('KeyType','double', 'ValueType','any');
                    child(flag1) = 1;
                    PPi(flag2) = child;
                end
            end
        end
        
        save([dataPath, 'results\PPI'],'PPi') 
    end

end

