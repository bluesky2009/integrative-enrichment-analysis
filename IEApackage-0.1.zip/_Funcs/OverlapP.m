function [ P ] = OverlapP( op, L, k1, k2 )
%OVERLAPP Summary of this function goes here
%   Detailed explanation goes here
    P = 0;
    for r=1:10000
        X1 = randperm(L);
        X2 = randperm(L);
        
        rop = intersect(X1(1:k1),X2(1:k2));
        if length(rop)>=op
            P = P + 1;
        end
    end
    P = P/10000.0; 
end

