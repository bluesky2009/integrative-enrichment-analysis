function [ PsC ] = PathCross( GSH, PPi )
%PATHCROSS Summary of this function goes here
%   Detailed explanation goes here
    PsC = {};
    pi = 1;
    for i1=1:size(GSH,2)
        for i2=(i1+1):size(GSH,2)
            gs1 = GSH{i1};
            gs2 = GSH{i2};
            
            PsC{pi}.path1 = gs1.pathname;
            PsC{pi}.path2 = gs2.pathname; 
                        
            PsC{pi}.members1 = [];
            PsC{pi}.members2 = [];                 
            
            for j1=1:length(gs1.genes)
                for j2=1:length(gs2.genes)
                    r1 = gs1.genes(j1);
                    r2 = gs2.genes(j2);
                    
                    try
                        ns = keys(PPi(r1));
                             
                        if sum(find(ns==r2))>0
                            PsC{pi}.members1 = [PsC{pi}.members1,r1];
                            PsC{pi}.members2 = [PsC{pi}.members2,r2];    
                        end
                    catch
                        continue
                    end
                end
            end     
            
            PsC{pi}.members1 = unique(PsC{pi}.members1);
            PsC{pi}.members2 = unique(PsC{pi}.members2);  
        end
    end           

end

