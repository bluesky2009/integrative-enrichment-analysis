        % General statistics on DEG & DEVG 
        % DEG: index of DEGs
        % DEVG: index of DEVGs
        % Stat: 
        % PG_DEG: index of pathway genes in DEGs
        % PG_DEVG: index of pathway genes in DEVGs
        % DG_DEG: index of disease genes in DEGs
        % DG_DEVG: index of disease genes in DEVGs
        % DEGup: index of DEGs with down-regulation in case
        % DEGdown: index of DEGs with up-regulation in case
        % DEVGup: index of DEVGs with tight-regulation in case
        % DEVGdown: index of DEVGs with losse-regulation in case
        % C: (z-socre) data of control samples
        % D: (z-socre) data of case samples
        % tP: P-value of all genes, which determine the DEGs
        % tPa: P-value of all genes, which determine the DEVGs
function [ DEG, DEVG, Stat, Gname, PG_DEG, PG_DEVG, DG_DEG, DG_DEVG, DEGup, DEGdown, DEVGup, DEVGdown, C, D, p ,pa ] = step0statistic(dataFile,dataPath,tP,tPa)
        
    mi = 1;
    %% Load processed data
    dataFile;
    load(dataFile) %'.\results\WorkData'    % The whole data matrix

    %% Prepare groups of data and disease labels
    % Remove the gene with missing data
    [nanrow,c] = find(isnan(Mdata));
    Mdata([nanrow],:) = [];
    genename([nanrow],:) = [];
    Zdata = Mdata;
    
    Gname = genename;

    C = Zdata(:,[class2]);% data from control samples[class2]
    D = Zdata(:,[class1]);% data from case samples [class1]
    X = [C,D]; % Reoganized data as [control samples,case samples]
    Lcd = [ones(1,length(class2)), 2*ones(1,length(class1))]; % Class label for accuracy evaluation

    if tP>=1 || tP<=0
        tP = 0.05;  % The threshold of significance test 0.01
    end
    if tPa>=1 || tPa<=0
        tPa = 0.05;  % The threshold of significance test 0.01
    end    
    
   %% Get DEGs and DEVGs    
    % Get the DEGs
    p = mattest(C,D); % P-v of all genes
    FDR = mafdr(p);
    FC = mean(C')./mean(D');
    mean(D')
    
    trow_ttest = find(p<=tP); % The list of DEGs
    tmp = find(FDR<=0.01);
    if length(tmp)>=200
        trow_ttest = tmp;
    else 
        tmp = union(find(FC>1.5),find(FC<1/1.5));
        tmp = intersect(tmp,trow_ttest);
        if length(tmp)>=200
            trow_ttest = tmp;
        else
            [sA,index] = sort(p);
            trow_ttest = index(1:(length(p)/100));
        end
    end
    
    trow_deg_C = []; % The list of DEGs down-reulated in case
    trow_deg_D = []; % The list of DEGs up-reulated in case
    PG_deg = []; % The list of pathway genes in DEGs
    DG_deg = []; % The list of disease genes in DEGs
    for ai=1:size(X,1)
        if length(find(trow_ttest==ai))==0 % Remove genes can selected by T-test
            continue;
        else             
            for j=1:size(GSH,2) % Find pathway gene
                gs = GSH{j};
                gs.genes;
                        
                if sum(find(gs.genes==ai))>0
                    PG_deg = [PG_deg,ai];
                    break;
                end
            end  
            
            if sum(find(GeneCards==ai))>0 % find disease gene
                DG_deg = [DG_deg,ai];
            end
            
            if mean(C(ai,:))>=mean(D(ai,:)) 
                trow_deg_C = [trow_deg_C,ai]; % DEGs down-reulated in case
            else
                trow_deg_D = [trow_deg_D,ai]; % DEGs up-reulated in case
            end
        end
    end
    
    pgdeg = intersect(nGSH, trow_ttest);
    PG_deg; 
   
    % Get the DEVGs 
    trow_Attest = []; % The list of DEVGs
    trow_devg_C = []; % The list of DEVGs tight-reulated in case
    trow_devg_D = []; % The list of DEVGs loose-reulated in case
    PG_devg = []; % The list of pathway genes in DEVGs
    DG_devg = []; % The list of disease genes in DEVGs
    
    pa = [];  % Pa-v of all genes
    XF = mean(X')';
    XC = C;
    XD = D;
    for ai=1:size(XF,1)
        XC(ai,:) = abs(XC(ai,:)-XF(ai)).^mi;
        XD(ai,:) = abs(XD(ai,:)-XF(ai)).^mi;
        xp = ranksum(XC(ai,:),XD(ai,:));
        pa = [pa,xp];
    end
    pa;
    
    FDR = mafdr(pa);
    FC = mean(XC')./mean(XD');
        
    trow_Attest = find(pa<=tP); % The list of DEGs
    size(trow_Attest)
    tmp = find(FDR<=0.01);
    if length(tmp)>=200
        trow_Attest = tmp;
    else 
        tmp = union(find(FC>1.5),find(FC<1/1.5));
        tmp = intersect(tmp,trow_Attest);
        if length(tmp)>=200
            trow_Attest = tmp;
        else
            [sA,index] = sort(pa);
            trow_Attest = index(1:(length(pa)/100));
        end
    end    
    size(trow_Attest)
    trow_Attest = setdiff(trow_Attest, trow_ttest);
    size(trow_Attest)
    
    
    for ai=1:size(XF,1)   
        if length(find(trow_Attest==ai))==0  % Remove genes can selected by T-test
            continue;
        else
            for j=1:size(GSH,2) % Find pathway gene
                gs = GSH{j};
                gs.genes;
                        
                if sum(find(gs.genes==ai))>0
                    PG_devg = [PG_devg,ai];
                    break;
                end
            end  
             
            if sum(find(GeneCards==ai))>0 % Find disease gene
                DG_devg = [DG_devg,ai];
            end

            if mean(XC(ai,:))>=mean(XD(ai,:))
                trow_devg_C = [trow_devg_C,ai]; % DEVGs tight-reulated in case
            else
                trow_devg_D = [trow_devg_D,ai]; % DEVGs loose-reulated in case
            end
        end
    end  
    
    % Stat gives the signficance of overlap among DEGs or DEVGs and pathway
    % genes or disease genes
    Stat = [length(trow_ttest),length(PG_deg),length(DG_deg),length(trow_Attest),length(PG_devg),length(DG_devg)]
    Stat = [Stat,1-hygecdf(length(PG_deg),length(genename),length(nGSH),length(trow_ttest))];
    Stat = [Stat,1-hygecdf(length(DG_deg),length(genename),length(GeneCards),length(trow_ttest))];
    Stat = [Stat,1-hygecdf(length(PG_devg),length(genename),length(nGSH),length(trow_Attest))];
    Stat = [Stat,1-hygecdf(length(DG_devg),length(genename),length(GeneCards),length(trow_Attest))];
    
    DEG = trow_ttest;
    DEVG = trow_Attest;
    DEGup = trow_deg_C;
    DEGdown = trow_deg_D;
    DEVGup = trow_devg_C;
    DEVGdown = trow_devg_D;
    
    PG_DEG = PG_deg;
    PG_DEVG = PG_devg;
    DG_DEG = DG_deg;
    DG_DEVG = DG_devg;
end