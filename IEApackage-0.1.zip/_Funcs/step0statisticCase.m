%% Select genes with PV < tP (0.05 as default), 
%% so that different methods will get different numbers of genes for clustering
function [ ] = step0statisticCase(Gname1, Gname2, C1, D1, C2, D2, tP1, tPa1, tP2, tPa2, DEGup1, DEGdown1, DEVGup1, DEVGdown1, DEGup2, DEGdown2, DEVGup2, DEVGdown2, dataPath)
        
    degUP1 = Gname1(DEGup1);
    devgUP1 = Gname1(DEVGup1);
    degUP2 = Gname2(DEGup2);
    devgUP2 = Gname2(DEVGup2);
    
    degDOWN1 = Gname1(DEGdown1);
    devgDOWN1 = Gname1(DEVGdown1);
    degDOWN2 = Gname2(DEGdown2);
    devgDOWN2 = Gname2(DEVGdown2);
    
    degUP = intersect(degUP1,degUP2);
    degDOWN = intersect(degDOWN1,degDOWN2);
    
    devgUP = intersect(devgUP1,devgUP2);
    devgDOWN = intersect(devgDOWN1,devgDOWN2);  
 
    for i=1:length(degDOWN)
        g = degDOWN(i);
        hit1 = find(strcmp(Gname1,g));
        hit2 = find(strcmp(Gname2,g));
        [g,tP1(hit1),tPa1(hit1),tP2(hit2),tPa2(hit2)];
    end
    for i=1:length(degUP)
        g = degUP(i);
        hit1 = find(strcmp(Gname1,g));
        hit2 = find(strcmp(Gname2,g));
        [g,tP1(hit1),tPa1(hit1),tP2(hit2),tPa2(hit2)];
    end
    for i=1:length(devgDOWN)
        g = devgDOWN(i);
        hit1 = find(strcmp(Gname1,g));
        hit2 = find(strcmp(Gname2,g));
        [g,tP1(hit1),tPa1(hit1),tP2(hit2),tPa2(hit2)];
    end
    for i=1:length(devgUP)
        g = devgUP(i);
        hit1 = find(strcmp(Gname1,g));
        hit2 = find(strcmp(Gname2,g));
        [g,tP1(hit1),tPa1(hit1),tP2(hit2),tPa2(hit2)];
    end
   
    hit1 = find(strcmp(Gname1,'MYC'));
    hit2 = find(strcmp(Gname2,'MYC'));
    
    hit3 = find(strcmp(Gname1,'INS-IGF2'));
    hit4 = find(strcmp(Gname2,'INS-IGF2'));
    
    hit5 = find(strcmp(Gname1,'HOXD8'));
    hit6 = find(strcmp(Gname2,'HOXD8'));
    
    hit7 = find(strcmp(Gname1,'REXO1'));
    hit8 = find(strcmp(Gname2,'REXO1'));
    
    H = figure();
    set(gcf,'Position',[0 0 1620 840]);
              
    subplot(4,4,1)
    plot(1:size(C1,2),C1(hit1,:),'b*');
    hold on
    plot((size(C1,2)+1):(size(C1,2)+size(D1,2)),D1(hit1,:),'r*');
    xlabel('Samples');
    ylabel('MYC expressions');
    title('(A)');
    subplot(4,4,2)
    plot(1:size(C1,2),C1(hit3,:),'b*');
    hold on
    plot((size(C1,2)+1):(size(C1,2)+size(D1,2)),D1(hit3,:),'r*');   
    xlabel('Samples');
    ylabel('INS-IGF2 expressions');
    title('(B)');
    subplot(4,4,3)
    plot(1:size(C1,2),C1(hit5,:),'b*');
    hold on
    plot((size(C1,2)+1):(size(C1,2)+size(D1,2)),D1(hit5,:),'r*');  
    xlabel('Samples');
    ylabel('HOXD8 expressions');
    title('(C)');
    subplot(4,4,4)
    plot(1:size(C1,2),C1(hit7,:),'b*');
    hold on
    plot((size(C1,2)+1):(size(C1,2)+size(D1,2)),D1(hit7,:),'r*');  
    xlabel('Samples');
    ylabel('REXO1 expressions');
    title('(D)');
    
    subplot(4,4,5)
    V = [C1(hit1,:), D1(hit1,:)];
    L = [ones(size(C1,2),1)',3*ones(size(D1,2),1)'];
    boxplot(V',L')
    xlabel('Sample groups');
    ylabel('Expression range of MYC');
    set(gca,'xtick',[1,2]);
    set(gca,'xticklabel',{'Control','Case'});
    title('(E)');
    subplot(4,4,6)
    V = [C1(hit3,:), D1(hit3,:)];
    L = [ones(size(C1,2),1)',3*ones(size(D1,2),1)'];
    boxplot(V',L') 
    xlabel('Sample groups');
    ylabel('Expression range of INS-IGF2');
    set(gca,'xtick',[1,2]);
    set(gca,'xticklabel',{'Control','Case'});
    title('(F)');
    subplot(4,4,7)
    V = [C1(hit5,:), D1(hit5,:)];
    L = [ones(size(C1,2),1)',3*ones(size(D1,2),1)'];
    boxplot(V',L')
    xlabel('Sample groups');
    ylabel('Expression range of HOXD8');
    set(gca,'xtick',[1,2]);
    set(gca,'xticklabel',{'Control','Case'});
    title('(G)');
    subplot(4,4,8)
    V = [C1(hit7,:), D1(hit7,:)];
    L = [ones(size(C1,2),1)',3*ones(size(D1,2),1)'];
    boxplot(V',L')
    xlabel('Sample groups');
    ylabel('Expression range of REXO1');
    set(gca,'xtick',[1,2]);
    set(gca,'xticklabel',{'Control','Case'});
    title('(H)');
    
    subplot(4,4,9)
    plot(1:size(C2,2),C2(hit2,:),'b*');
    hold on
    plot((size(C2,2)+1):(size(C2,2)+size(D2,2)),D2(hit2,:),'r*');
    xlabel('Samples');
    ylabel('MYC expressions');
    title('(I)');
    subplot(4,4,10)
    plot(1:size(C2,2),C2(hit4,:),'b*');
    hold on
    plot((size(C2,2)+1):(size(C2,2)+size(D2,2)),D2(hit4,:),'r*');  
    xlabel('Samples');
    ylabel('INS-IGF2 expressions');
    title('(J)');
    subplot(4,4,11)
    plot(1:size(C2,2),C2(hit6,:),'b*');
    hold on
    plot((size(C2,2)+1):(size(C2,2)+size(D2,2)),D2(hit6,:),'r*'); 
    xlabel('Samples');
    ylabel('HOXD8 expressions');
    title('(K)');
    subplot(4,4,12)
    plot(1:size(C2,2),C2(hit8,:),'b*');
    hold on
    plot((size(C2,2)+1):(size(C2,2)+size(D2,2)),D2(hit8,:),'r*');   
    xlabel('Samples');
    ylabel('REXO1 expressions');
    title('(L)');
    
    subplot(4,4,13)
    V = [C2(hit2,:), D2(hit2,:)];
    L = [ones(size(C2,2),1)',3*ones(size(D2,2),1)'];
    boxplot(V',L')
    xlabel('Sample groups');
    ylabel('Expression range of MYC');
    set(gca,'xtick',[1,2]);
    set(gca,'xticklabel',{'Control','Case'});
    title('(M)');
    subplot(4,4,14)
    V = [C2(hit4,:), D2(hit4,:)];
    L = [ones(size(C2,2),1)',3*ones(size(D2,2),1)'];
    boxplot(V',L') 
    xlabel('Sample groups');
    ylabel('Expression range of INS-IGF2');
    set(gca,'xtick',[1,2]);
    set(gca,'xticklabel',{'Control','Case'});
    title('(N)');
    subplot(4,4,15)
    V = [C2(hit6,:), D2(hit6,:)];
    L = [ones(size(C2,2),1)',3*ones(size(D2,2),1)'];
    boxplot(V',L')
    xlabel('Sample groups');
    ylabel('Expression range of HOXD8');
    set(gca,'xtick',[1,2]);
    set(gca,'xticklabel',{'Control','Case'});
    title('(O)');
    subplot(4,4,16)
    V = [C2(hit8,:), D2(hit8,:)];
    L = [ones(size(C2,2),1)',3*ones(size(D2,2),1)'];
    boxplot(V',L')
    xlabel('Sample groups');
    ylabel('Expression range of REXO1');
    set(gca,'xtick',[1,2]);
    set(gca,'xticklabel',{'Control','Case'});
    title('(P)');
    
    set(gcf,'PaperPositionMode','auto')
    %saveas(gcf, 'Figure R2_1', 'pdf'); 
    print(H, '-dpdf', [dataPath,'//Figure R2_1_.pdf']);
   
end