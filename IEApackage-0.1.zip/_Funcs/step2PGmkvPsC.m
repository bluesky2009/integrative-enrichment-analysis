% Enrichment of PPI neighbors
function [ PsC, PSC, PCN ] = step2PGmkvPsC(PPi,DEG,DEVG,PG_DEG,PG_DEVG,C,D,dataFile,dataPath,tP)
       
    Status = 'step2PGmkvPsC Run'
    mi = 1;
    %% Load processed data
    dataFile;
    load(dataFile) %'.\results\WorkData'    % The whole data matrix

    % Sparse neighbouring 0-1 matrix of PPI
    I = [];
    J = [];
    S = [];
    nodes = keys(PPi);
    for k=1:size(nodes,2)
        node = nodes{k};
        try
            child = keys(PPi(node));
            
            sumPCC = 0;
            for kk=1:length(child)
                r11 = node;
                r22 = child{kk};
                            
                cc = abs(corr(C(r11,:)',C(r22,:)')-corr(D(r11,:)',D(r22,:)'));

                sumPCC = cc + sumPCC;
            end

            for kk=1:length(child)
                r1 = node;
                r2 = child{kk};
                                
                cc = abs(corr(C(r1,:)',C(r2,:)')-corr(D(r1,:)',D(r2,:)'));
                
                I = [I,r1];
                J = [J,r2];
                S = [S,cc*1.0/sumPCC];
            end
        catch
            err = 'Err'
            continue;
        end
    end
    Mov = sparse(I,J,S,length(genename),length(genename));
    
    % Get DEGs and DEVGs
    trow_ttest = DEG;
    trow_Attest = DEVG;
    
   %% Detect pathway crosstalk by RWR 
    PsC = []; % List of pathway crosstalks
    PSC = []; % List of significant pathway crosstalks
    PCN = ones(size(GSH,2),size(GSH,2)); % Adjacent matrix (PV-weighted) of the map of pathways
    for j=1:size(GSH,2) % Scan each pathway
        gs = GSH{j};
        gs.genes;
                        
        Lp = []; % Vector for RWR
        for ai=1:length(genename)
            if sum(find(gs.genes==ai))>0
                if sum(find(trow_ttest==ai))>0 || sum(find(trow_Attest==ai))>0
                    Lp = [Lp,1]; % The gene is a DEG or DEVG in this pathway
                    if sum(find(PG_DEG==ai))+sum(find(PG_DEVG==ai))==0
                        Err = 'step2PGmkvPsC Err'
                    end
                else
                    Lp = [Lp,0];
                end
            else
                Lp = [Lp,0];
            end
        end
        
        % RWR
        lamda = 0.8;
        L = Lp';
        res = 1;
        while res>0.000001
            LL = (1-lamda)*Mov*L+lamda*Lp';
            res = normest(LL-L);
            L = LL;
        end
        Lp = L';
        
        % Remove seed genes
        for k=1:length(gs.genes)
            Lp(gs.genes(k)) = 0;
        end
    
        [sL, inxp] = sort(Lp,'descend');
        nonzero = find(Lp>0);
        Np = min(length(nonzero),length(trow_ttest)+length(trow_Attest));
        Np = min(100,Np);
        inxp = inxp(1:Np); % The top-100 genes in RWR
     
        PV = []; % P-value of candidates of pathway crosstalks
        for k=1:size(GSH,2)
            if k==j
                PV = [PV,1];
                continue % Remove the pathway itself when finding its patners
            end
            gs_k = GSH{k};
            
            hits = intersect(gs_k.genes,inxp);
            if length(hits)==0
                PV = [PV,1];
                continue
            end
            dP = 1-hygecdf(length(hits), length(nodes), length(gs_k.genes), Np); 
            PV = [PV,dP];
            
            if length(PsC)==0
                PsC = [gs.pathname,gs_k.pathname,dP,length(hits),length(gs_k.genes),Np];
            else
                PsC = [PsC;[gs.pathname,gs_k.pathname,dP,length(hits),length(gs_k.genes),Np]];
            end
        end    
        
        efp = find(PV<=tP); % Select significant pathway crosstalks
        for k=1:length(efp)
            r1 = j;
            r2 = efp(k);
            
            PCN(r1,r2) = PV(r2);
        end 
        
    end        
    
   %% Select significant pathway crosstalk 
    for i=1:size(GSH,2)
        for j=(i+1):size(GSH,2)
            if PCN(i,j)<1 && PCN(j,i)<1
                if length(PSC)==0
                    PSC = [GSH{i}.pathname,GSH{j}.pathname,PCN(i,j),PCN(j,i)];
                else
                    PSC = [PSC;[GSH{i}.pathname,GSH{j}.pathname,PCN(i,j),PCN(j,i)]];
                end
            end
        end
    end

    %save([dataPath, 'results\ModuleData'])    %ModuleData
end

